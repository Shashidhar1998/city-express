package com.onlineshopping.outletservice.repositories;


import com.onlineshopping.outletservice.models.OutletEmployeeRole;
import com.onlineshopping.outletservice.models.OutletEmployeeRoleName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OutletEmployeeRoleRepository  extends JpaRepository<OutletEmployeeRole, Long> {

    Optional<OutletEmployeeRole> findByName(OutletEmployeeRoleName name);
}
