package com.onlineshopping.outletservice.services;

import com.onlineshopping.outletservice.models.Outlet;
import com.onlineshopping.outletservice.models.OutletAddress;
import com.onlineshopping.outletservice.models.OutletEmployee;
import com.onlineshopping.outletservice.models.OutletOwner;
import com.onlineshopping.outletservice.repositories.OutletAddressRepository;
import com.onlineshopping.outletservice.repositories.OutletRepository;
import com.onlineshopping.outletservice.requests.outlet.OutletRegisterRequest;
import com.onlineshopping.outletservice.services.aws.S3BucketStorageService;
import com.onlineshopping.outletservice.services.mail.EmailService;
import com.onlineshopping.outletservice.utils.OutletUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class OutletService {

    @Autowired
    OutletRepository outletrepository;

    @Autowired
    OutletAddressRepository outletAddressRepository;

    @Autowired
    EmailService emailService;

    @Autowired
    S3BucketStorageService s3BucketStorageService;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    EmployeeDetailsServiceImpl employeeDetailsService;

    public List<Outlet> getAllOutlets() {
        return outletrepository.findAll();
    }

    public Outlet getOutletById(Long outlet_id) {
        return outletrepository.getById(outlet_id);
    }

    public Optional<Outlet> findOutletById() {
        String OutletId = ((EmployeePrinciple) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getOutletId();
        return outletrepository.findByShopId(OutletId);
    }

    public Optional<Outlet> findOutletByShopId(String outlet_name) {
        return outletrepository.findByShopId(outlet_name);
    }

    public List<OutletAddress> getoutletsbylatandlong() {
        return outletAddressRepository.findAll();
    }

    public Outlet createOutlet(OutletRegisterRequest outletObj) throws IOException {
        //create Unique Id and Create Outlet
        String shopId = createUniqueIdForOutlet(outletObj.getName());
        Outlet outlet = setOutletDetails(outletObj,shopId);
        //create owner as employee
        OutletEmployee employee = new OutletEmployee(outletObj.getOwnerMail(),outletObj.getOwnerMail(),outletObj.getOwnerMobile(),encoder.encode(outlet.getShopId()));
        List<Outlet> outlets = new ArrayList<Outlet>();
        outlets.add(outlet);
        employee.setOutlets(outlets);
        if(employeeDetailsService.saveOwnerAsEmployee(employee)){
            emailService.sendTemplateEmail(employee,outlet.getShopId());
        }
        return outlet;
    }

    public String createUniqueIdForOutlet(String outletName){
        String shopId = "";
        Boolean shopIdAvailable = false;
        OutletUtil outletutil = new OutletUtil();
        //Create Random ShopId and check whether it exists in database
        while(!shopIdAvailable){
            shopId = outletutil.createShopId(outletName);
            Optional<Outlet> outletIdExists = findOutletByShopId(shopId);
            if(!outletIdExists.isPresent()){
                shopIdAvailable = true;
            }
        }
        return shopId;
    }

    private Outlet setOutletDetails(OutletRegisterRequest outletObj, String shopId) {
        Outlet outlet = new Outlet();
        outlet.setShopId(shopId);
        outlet.setShopName(outletObj.getName());
        outlet.setType(outletObj.getType());
        outlet.setGst(outletObj.getGst());

        //set image if user submitted any
        //outlet.setImagePath(uploadOutletImage(file));
        outlet.setImagePath("Temp data");

        // Set Address Details from Request Object
        OutletAddress outletAddress = new OutletAddress();
        outletAddress.setAddress1(outletObj.getAddress());
        outletAddress.setCity(outletObj.getCity());
        outletAddress.setPincode(outletObj.getPincode());
        outletAddress.setState(outletObj.getState());

        outlet.setAddress(outletAddress);

        // Set Owner Details from Request Object
        OutletOwner outletOwner = new OutletOwner();
        outletOwner.setOwnerName(outletObj.getOwnerName());
        outletOwner.setShopId(shopId);
        outletOwner.setOwnerMail(outletObj.getOwnerMail());
        outletOwner.setOwnerMobile(outletObj.getOwnerMobile());

        outlet.setOwner(outletOwner);

        return outlet;
    }

    public String uploadOutletImage(MultipartFile file) {
        return s3BucketStorageService.uploadFile(file);
    }


    public String deleteOutletImage(String fileUrl) {
        return  s3BucketStorageService.deleteFileFromS3Bucket(fileUrl);
    }
}