package com.onlineshopping.outletservice.responses.product;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ProductCreateResponse {
    private Long shopId;
    private Long categoryId;
    private String name;
    private String description;
    private String company;
    private Long price;
    private Long discount;
}
