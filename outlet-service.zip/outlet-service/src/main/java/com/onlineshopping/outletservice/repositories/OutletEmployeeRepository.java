package com.onlineshopping.outletservice.repositories;

import com.onlineshopping.outletservice.models.OutletEmployee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OutletEmployeeRepository  extends JpaRepository<OutletEmployee, Long> {

    Optional<OutletEmployee> findByUsername(String username);
}
