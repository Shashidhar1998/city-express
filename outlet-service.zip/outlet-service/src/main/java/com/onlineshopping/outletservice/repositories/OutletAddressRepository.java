package com.onlineshopping.outletservice.repositories;

import com.onlineshopping.outletservice.models.OutletAddress;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OutletAddressRepository extends JpaRepository<OutletAddress, Long> {
}
