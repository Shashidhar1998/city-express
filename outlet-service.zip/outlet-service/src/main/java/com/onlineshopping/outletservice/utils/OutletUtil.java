package com.onlineshopping.outletservice.utils;

import org.springframework.stereotype.Component;

@Component
public class OutletUtil {

    public String createShopId(String shopname){
        String[] arrOfStr = shopname.split(" |\\-");
        String ShopId = "";
        for (String a : arrOfStr){
            ShopId = ShopId + a.toUpperCase();
        }
        int number = (int)(Math.random() * 10000);
        String alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        int alphabet = (int)(Math.random() * 25);
        return (ShopId.substring(0,4) + number + alphabets.charAt(alphabet));
    }
}
