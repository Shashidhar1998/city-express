package com.onlineshopping.outletservice.services;

import com.onlineshopping.outletservice.models.Outlet;
import com.onlineshopping.outletservice.models.OutletEmployee;
import com.onlineshopping.outletservice.models.OutletEmployeeRole;
import com.onlineshopping.outletservice.models.OutletEmployeeRoleName;
import com.onlineshopping.outletservice.repositories.OutletEmployeeRepository;
import com.onlineshopping.outletservice.repositories.OutletEmployeeRoleRepository;
import com.onlineshopping.outletservice.repositories.OutletRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class EmployeeDetailsServiceImpl implements UserDetailsService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    OutletEmployeeRepository outletEmployeeRepository;

    @Autowired
    OutletEmployeeRoleRepository roleRepository;

    @Autowired
    OutletRepository outletRepository;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        OutletEmployee user = outletEmployeeRepository.findByUsername(username).orElseThrow(
                () -> new UsernameNotFoundException("User Not Found" + username)
        );
        return EmployeePrinciple.build(user);
    }

    public OutletEmployee saveOutletEmployee(OutletEmployee employee) {
        return outletEmployeeRepository.save(employee);
    }

    public Boolean saveOwnerAsEmployee(OutletEmployee employee) {
        try {
//            List<String> strRoles= new ArrayList<>();
//            strRoles.add("owner");
//            strRoles.add("employee");
//            strRoles.forEach( role ->{
//                switch (role){
//                    case "owner" :
//                        OutletEmployeeRole ownerRole = roleRepository.findByName(OutletEmployeeRoleName.ROLE_OWNER)
//                                .orElseThrow(() -> new RuntimeException("Issue with role"));
//                        roles.add(ownerRole);
//                        break;
//                    case "employee" :
//                        OutletEmployeeRole employeeRole = roleRepository.findByName(OutletEmployeeRoleName.ROLE_EMPLOYEE)
//                                .orElseThrow(() -> new RuntimeException("Issue with role"));
//                        roles.add(employeeRole);
//                        break;
//                }});
            Set<OutletEmployeeRole> roles = new HashSet<>();
            OutletEmployeeRole ownerRole = roleRepository.findByName(OutletEmployeeRoleName.ROLE_OWNER)
                    .orElseThrow(() -> new RuntimeException("Issue with role Type : Owner"));
            roles.add(ownerRole);
            OutletEmployeeRole employeeRole = roleRepository.findByName(OutletEmployeeRoleName.ROLE_EMPLOYEE)
                    .orElseThrow(() -> new RuntimeException("Issue with role Type : Employee"));
            roles.add(employeeRole);
            employee.setRoles(roles);
            outletEmployeeRepository.save(employee);
            return true;
        }catch (Exception e){
            logger.error("Something went wrong while Creating the Employee for Outlet",e);
        }
        return false;
    }
}


