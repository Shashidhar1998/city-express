package com.onlineshopping.outletservice.repositories;

import com.onlineshopping.outletservice.models.Outlet;
import com.onlineshopping.outletservice.models.OutletEmployee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.Optional;

@Repository
public interface OutletRepository  extends JpaRepository<Outlet, Long> {

    Optional<Outlet> findByShopId(String shopId);
}
