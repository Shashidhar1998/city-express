package com.onlineshopping.outletservice.controllers;


import com.onlineshopping.outletservice.responses.outlet.EmployeeAuthResponse;
import com.onlineshopping.outletservice.services.EmployeePrinciple;
import com.onlineshopping.outletservice.utils.JwtProvider;
import com.onlineshopping.outletservice.models.OutletEmployee;
import com.onlineshopping.outletservice.models.OutletEmployeeRole;
import com.onlineshopping.outletservice.models.OutletEmployeeRoleName;
import com.onlineshopping.outletservice.repositories.OutletEmployeeRepository;
import com.onlineshopping.outletservice.repositories.OutletEmployeeRoleRepository;
import com.onlineshopping.outletservice.requests.shopadmin.OutletAuthRequest;
import com.onlineshopping.outletservice.services.EmployeeDetailsServiceImpl;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.Set;
import org.slf4j.Logger;

@RestController
@CrossOrigin(origins = "*")
public class OutletEmployeeController {

    Logger logger = LoggerFactory.getLogger(OutletEmployeeController.class);
    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder encoder;

    @Autowired
    private EmployeeDetailsServiceImpl employeeDetailsService;

    @Autowired
    private OutletEmployeeRoleRepository roleRepository;

    @Autowired
    private OutletEmployeeRepository employeeRepository;

    @Autowired
    private JwtProvider jwtProvider;

//    @PostMapping("/createemployee")
//    public OutletEmployee createEmployee(@RequestBody EmployeeRegisterReq obj ){
//        OutletEmployee employee = new OutletEmployee(obj.getUsername(),obj.getUsername(),obj.getMobileNumber(),encoder.encode(obj.getPassword()));
//
//        Set<String> strRoles = obj.getRoles();
//        Set<OutletEmployeeRole> roles = new HashSet<>();
//
//        strRoles.forEach( role ->{
//            switch (role){
//                case "owner" :
//                    OutletEmployeeRole ownerrole = roleRepository.findByName(OutletEmployeeRoleName.ROLE_OWNER)
//                        .orElseThrow(() -> new RuntimeException("Issue with role"));
//                    roles.add(ownerrole);
//
//                    break;
//                case "employee" :
//                    OutletEmployeeRole employeerole = roleRepository.findByName(OutletEmployeeRoleName.ROLE_EMPLOYEE)
//                            .orElseThrow(() -> new RuntimeException("Issue with role"));
//                    roles.add(employeerole);
//                    break;
//            }});
//        employee.setRoles(roles);
//        return employeeRepository.save(employee);
//    }

    @PostMapping("/signin")
    public ResponseEntity<?> Authenticate(@RequestBody OutletAuthRequest authenticationRequest) throws Exception{
        try {
            String username = authenticationRequest.getUsername();
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(username,authenticationRequest.getPassword()));
            SecurityContextHolder.getContext().setAuthentication(authentication);

            String token = jwtProvider.generateJwtToken(authentication);
            EmployeePrinciple employeePrinciple = (EmployeePrinciple) authentication.getPrincipal();
            return ResponseEntity.ok(new EmployeeAuthResponse(token, employeePrinciple.getAuthorities().toString(), employeePrinciple.getOutletId()));

        }
        catch(BadCredentialsException e) {
            throw new Exception("Incorrect Username or Password Exception",e);
        }
        catch(Exception e) {
            throw new Exception("Something Went Wrong",e);
        }
    }

    @GetMapping("/public/getemployees")
    public ResponseEntity<?> getEmployees(){
        logger.info("Info");
        return ResponseEntity.ok(employeeRepository.findAll());
    }
}
