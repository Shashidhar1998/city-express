package com.onlineshopping.outletservice.services;

import com.onlineshopping.outletservice.repositories.OutletAddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OutletAddressService {
    @Autowired
    OutletAddressRepository outletAddressRepository;


}
