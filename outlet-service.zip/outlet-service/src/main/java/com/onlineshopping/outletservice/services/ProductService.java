package com.onlineshopping.outletservice.services;

import com.onlineshopping.outletservice.models.Category;
import com.onlineshopping.outletservice.models.Outlet;
import com.onlineshopping.outletservice.models.Product;
import com.onlineshopping.outletservice.repositories.CategoryRepository;
import com.onlineshopping.outletservice.repositories.OutletRepository;
import com.onlineshopping.outletservice.repositories.ProductRepository;
import com.onlineshopping.outletservice.requests.product.ProductCreateRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ProductService {

    @Autowired
    ProductRepository productrepository;

    @Autowired
    OutletRepository  outletRepository;

    @Autowired
    CategoryRepository categoryRepository;
    public List<Product> getAllOutlets() {
        List<Product> products = new ArrayList<>();
        productrepository.findAll().forEach(products::add);
        return products;
    }

    public Product createProduct(ProductCreateRequest productObj) {
        Category category = categoryRepository.getById(productObj.getCategoryId());
        Product product = new Product(productObj.getName(),productObj.getDescription(),productObj.getCompany(),productObj.getPrice(),productObj.getDiscount());
        List<Product> products = category.getProducts();
        products.add(product);
        category.setProducts(products);
        categoryRepository.save(category);
        return product;
    }

    public Product getProductById(Long product_id) {
        return productrepository.getById(product_id);
    }

    public Optional<Product> findProductById(Long product_id) {
        return productrepository.findById(product_id);
    }
}
