package com.onlineshopping.outletservice.models;


import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "outlet_employee")
public class OutletEmployee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;

    @Column(unique=true)
    private String mail;

    private String mobileNumber;
    private String password;

    @JsonManagedReference
    @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinTable(
            name = "employees_outlets",
            joinColumns = @JoinColumn(name = "outlet_employee_id"),
            inverseJoinColumns = @JoinColumn(name = "outlet_id"))
    private List<Outlet> outlets = new ArrayList<>();

    @JsonManagedReference
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "outlet_employee_roles",
               joinColumns = @JoinColumn(name = "outlet_employee_id"),
               inverseJoinColumns = @JoinColumn(name = "outlet_role_id"))
    private Set<OutletEmployeeRole> roles = new HashSet<>();

    public OutletEmployee() {
    }

    public OutletEmployee(String username, String mail, String mobileNumber, String password) {
        this.username = username;
        this.mail = mail;
        this.mobileNumber = mobileNumber;
        this.password = password;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<OutletEmployeeRole> getRoles() {
        return roles;
    }

    public void setRoles(Set<OutletEmployeeRole> roles) {
        this.roles = roles;
    }

    public List<Outlet> getOutlets() {
        return outlets;
    }

    public void setOutlets(List<Outlet> outlets) {
        this.outlets = outlets;
    }
}
