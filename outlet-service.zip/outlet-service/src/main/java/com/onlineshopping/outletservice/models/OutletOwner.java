package com.onlineshopping.outletservice.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import javax.validation.constraints.Pattern;
import java.util.Date;

@Entity
@Table(name = "outlet_owner")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class OutletOwner {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "shop_id",unique = true)
    private String shopId;

    @Column(name = "shop_owner_name")
    private String ownerName;

    @Column(name = "shop_owner_mail")
    @Pattern(regexp="(^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$)")
    private String ownerMail;

    @Column(name = "shop_owner_mobile")
    @Pattern(regexp="(^$|[0-9]{10})")
    private String ownerMobile;

    @Column(name = "timestamp")
    @CreationTimestamp
    private Date timestamp;

    @Column(name = "last_updated")
    @UpdateTimestamp
    private Date lastUpdated;

    @JsonBackReference
    @OneToOne(mappedBy = "owner")
    private Outlet outlet;
}
