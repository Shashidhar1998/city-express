package com.onlineshopping.outletservice.controllers;

import com.onlineshopping.outletservice.models.Outlet;
import com.onlineshopping.outletservice.requests.outlet.OutletRegisterRequest;
import com.onlineshopping.outletservice.responses.outlet.OutletRegisterResponse;
import com.onlineshopping.outletservice.services.OutletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.ConstraintViolationException;
import java.util.*;

@CrossOrigin(origins = "*")
@RestController
public class OutletController {

    @Autowired
    OutletService outletservice;

    @GetMapping("/public/outlets-list")
    public List<Outlet> getAllOutlets() {
        return outletservice.getAllOutlets();
    }

    @GetMapping("/getOutlet")
    public ResponseEntity<Object> findOutletById(){
        Optional<Outlet> outlet = outletservice.findOutletById();
        if(outlet.isPresent()){
           return new ResponseEntity<Object>(outlet,HttpStatus.OK);
        }
        else{
            return new ResponseEntity<Object>("Not Found",HttpStatus.OK);
        }
    }


    @PostMapping("/createoutlet")
    public ResponseEntity<Object> createOutlet(@RequestBody OutletRegisterRequest outletReq) {
        HttpHeaders headers = new HttpHeaders();
        try {
            Outlet outlet = outletservice.createOutlet(outletReq);
            String message = "Username : " + outletReq.getOwnerMail() +  "\n Password : " + outlet.getShopId();
            OutletRegisterResponse outletRegisterResponse = new OutletRegisterResponse(outlet.getShopId(),message,"200");
            return new ResponseEntity<Object>(outletRegisterResponse,headers, HttpStatus.CREATED);
        }
        catch(DataIntegrityViolationException e) {
            headers.add("Exception-message", "DataIntegrityViolationException");
            return new ResponseEntity<Object>("Shop Id Should be Unique" + e.getMessage(), headers, HttpStatus.BAD_REQUEST);
        }
        catch(ConstraintViolationException e){
            headers.add("Exception-message", "ConstraintViolationException");
            return new ResponseEntity<Object>("Please check Mobile Number/Email", headers, HttpStatus.BAD_REQUEST);
        }
        catch(Exception e){
            headers.add("Exception-message", e.getMessage());
            return new ResponseEntity<Object>("Exception while creating outlet " + e.getMessage(), headers, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/getlocations")
    public ResponseEntity<Object> getOutletsInLocation(){
        return new ResponseEntity<Object>(outletservice.getoutletsbylatandlong(), HttpStatus.ACCEPTED);
    }

}
