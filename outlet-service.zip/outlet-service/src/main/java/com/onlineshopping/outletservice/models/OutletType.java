package com.onlineshopping.outletservice.models;

public enum OutletType {
    FOOD,
    GROCERIES,
    FASHION,
    BAKERY,
    MEDICINE,
    VEGETABLES,
}
