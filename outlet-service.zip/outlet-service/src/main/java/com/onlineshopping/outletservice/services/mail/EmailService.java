package com.onlineshopping.outletservice.services.mail;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.onlineshopping.outletservice.models.OutletEmployee;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;
import com.sendgrid.helpers.mail.objects.Personalization;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.Response;
import com.sendgrid.SendGrid;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Service
public class EmailService{
    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);
    public String sendTemplateEmail(OutletEmployee employee, String shopId) throws IOException {
        // the sender email should be the same as we used to Create a Single Sender Verification
        Email from = new Email("support@city-express.in","City Express");
        String subject = "Congratulations!!!";
        Email to = new Email(employee.getUsername());
        Mail mail = new Mail();
        // we create an object of our static class feel free to change the class on it's own file
        // I try to keep every think simple
        DynamicTemplatePersonalization personalization = new DynamicTemplatePersonalization();
        personalization.addTo(to);
        mail.setFrom(from);
        mail.setSubject(subject);
        // This is the first_name variable that we created on the template
        personalization.addDynamicTemplateData("username", employee.getUsername());
        personalization.addDynamicTemplateData("Password", shopId);
        mail.addPersonalization(personalization);
        mail.setTemplateId("d-c7bfbcaa8ea44a59bc14b356a1a3f93f");
        // this is the api key
        SendGrid sg = new SendGrid("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");
        Request request = new Request();

        try {
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());
            Response response = sg.api(request);
            logger.info(response.getBody());
            return response.getBody();
        } catch (IOException ex) {
            throw ex;
        }
    }

    private static class DynamicTemplatePersonalization extends Personalization {

        @JsonProperty(value = "dynamic_template_data")
        private Map<String, Object> dynamic_template_data;

        @JsonProperty("dynamic_template_data")
        public Map<String, Object> getDynamicTemplateData() {
            if (dynamic_template_data == null) {
                return Collections.<String, Object>emptyMap();
            }
            return dynamic_template_data;
        }

        public void addDynamicTemplateData(String key, String value) {
            if (dynamic_template_data == null) {
                dynamic_template_data = new HashMap<String, Object>();
                dynamic_template_data.put(key, value);
            } else {
                dynamic_template_data.put(key, value);
            }
        }

    }
    @Async
    public String sendTextEmail(OutletEmployee employee, String shopId) throws IOException {
        // the sender email should be the same as we used to Create a Single Sender Verification
        Email from = new Email("support@city-express.in","City Express");
        String subject = "Congratulations!!!";
        Email to = new Email(employee.getUsername());
        Content content = new Content("text/plain", "This is a test email" + shopId);
        Mail mail = new Mail(from, subject, to, content);

        SendGrid sg = new SendGrid("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");
        Request request = new Request();
        try {
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());
            Response response = sg.api(request);
            logger.info(response.getBody());
            return response.getBody();
        } catch (IOException ex) {
            throw ex;
        }
    }

}
