package com.onlineshopping.outletservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OutletServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
